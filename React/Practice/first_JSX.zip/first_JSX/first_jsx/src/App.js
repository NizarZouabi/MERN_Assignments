import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
          <h1>Hello Dojo!</h1>
          <h2>Things i need to do:</h2>
          <ul className="list">
            <li>Learn React</li>
            <li>Climb Mt. Everest</li>
            <li>Run a marathon</li>
            <li>Feed the cats</li>
        </ul>
      </header>
      </div>
  );
}

export default App;
