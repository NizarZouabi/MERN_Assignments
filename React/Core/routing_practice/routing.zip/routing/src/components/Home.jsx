import React from 'react';
import { } from "react-router-dom";

const Home = () => {
    return (
        <div>
            <h1>Welcome</h1>
        </div>
    );
}

export default Home;